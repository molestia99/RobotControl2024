#ifndef QDLDL_VERSION_H_
#define QDLDL_VERSION_H_

#define QDLDL_VERSION_MAJOR     0
#define QDLDL_VERSION_MINOR     1
#define QDLDL_VERSION_PATCH     6

#endif // #ifndef QDLDL_VERSION_H_
