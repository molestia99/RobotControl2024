.. _ruby_interface:


Ruby
========

The ruby interface can be installed as a Ruby gem and is documented `here <https://www.rubydoc.info/gems/osqp/>`_.
