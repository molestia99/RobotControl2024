.. _eigen_robotology:

C++ Eigen interface (osqp-eigen)
================================

The Eigen interface by Robotology group is documented `here <https://robotology.github.io/osqp-eigen/doxygen/doc/html/index.html>`_.
